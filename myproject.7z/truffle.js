module.exports = {
  networks: {
    development: {
       host: "127.0.0.1",
       port: 22000,
       network_id: "1006",
       gasPrice: 0,
       gas: 4500000
     }
   }   
};
