TradeRecon = artifacts.require("./CRUD.sol");

module.exports = function(deployer) {
  // Pass 42 to the contract as the first constructor parameter
  deployer.deploy(TradeRecon);
};
