# ldap-filter

API for handling LDAP-style filters

Derived entirely from the filter code in
[LDAPjs](https://github.com/mcavage/node-ldapjs)

## License

MIT.
